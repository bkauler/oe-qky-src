# Copyright (C) 2017 Intel Corporation
# Released under the MIT license (see COPYING.MIT)

from oeqa.core.case import OETestCase

class OECompatLayerTestCase(OETestCase):
    pass
