$a = 9.01e+21 - 9.01e+21 + 0.01;
print ("the value of a is ", $a, "\n");
