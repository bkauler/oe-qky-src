import os

os.system('touch /tmp/testfile.python')

a = 9.01e+21 - 9.01e+21 + 0.01
print("the value of a is %s" % a)
