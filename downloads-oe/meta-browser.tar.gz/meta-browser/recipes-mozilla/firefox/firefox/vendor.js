pref("general.useragent.compatMode.firefox", true);
pref("distribution.searchplugins.defaultLocale", "en-US");
// Forbid application updates
lockPref("app.update.enabled", false);
lockPref("extensions.update.enabled", false);
lockPref("extensions.autoDisableScopes", 10);
